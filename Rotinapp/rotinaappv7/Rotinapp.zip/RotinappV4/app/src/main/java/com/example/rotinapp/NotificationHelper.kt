package com.example.rotinapp

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import com.example.rotinapp.database.TaskEntity
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

const val CHANNEL_ID = "rotinapp_tasks"
const val EXTRA_TASK_TITLE = "task_title"
const val EXTRA_TASK_ID = "task_id"

class TaskAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TASK_TITLE) ?: "Tarefa"
        val taskId = intent.getIntExtra(EXTRA_TASK_ID, 0)
        showNotification(context, taskId, title)
    }
}

class BootReceiver : BroadcastReceiver() {
    @OptIn(DelicateCoroutinesApi::class)
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        GlobalScope.launch(Dispatchers.IO) {
            val db = com.example.rotinapp.database.TaskDatabase.getDatabase(context)
            val tasks = db.taskDao().getAllTasksOnce()
            tasks.forEach { task ->
                if (!task.isDone) scheduleTaskNotification(context, task)
            }
        }
    }
}

fun createNotificationChannel(context: Context) {
    val channel = NotificationChannel(
        CHANNEL_ID,
        "Lembretes de Tarefas",
        NotificationManager.IMPORTANCE_HIGH
    ).apply {
        description = "Notificações para lembrar das suas tarefas"
        enableVibration(true)
        enableLights(true)
    }
    val manager = context.getSystemService(NotificationManager::class.java)
    manager.createNotificationChannel(channel)
}

fun showNotification(context: Context, taskId: Int, taskTitle: String) {
    val manager = context.getSystemService(NotificationManager::class.java)

    val openIntent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
    }
    val pendingIntent = PendingIntent.getActivity(
        context, taskId, openIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("⏰ Hora da sua tarefa!")
        .setContentText(taskTitle)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setContentIntent(pendingIntent)
        .setAutoCancel(true)
        .build()

    manager.notify(taskId, notification)
}

fun canScheduleExactAlarms(context: Context): Boolean {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        return alarmManager.canScheduleExactAlarms()
    }
    return true
}

fun openExactAlarmPermissionSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = "package:${context.packageName}".toUri()
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}

fun scheduleTaskNotification(context: Context, task: TaskEntity) {
    val alarmManager = context.getSystemService(AlarmManager::class.java)

    val timeParts = task.time.split(":").map { it.trim() }
    if (timeParts.size != 2) return
    val hour = timeParts[0].toIntOrNull() ?: return
    val minute = timeParts[1].toIntOrNull() ?: return

    val calendar = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, hour)
        set(java.util.Calendar.MINUTE, minute)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) {
            add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
    }

    val intent = Intent(context, TaskAlarmReceiver::class.java).apply {
        putExtra(EXTRA_TASK_TITLE, task.title)
        putExtra(EXTRA_TASK_ID, task.id)
    }
    val pendingIntent = PendingIntent.getBroadcast(
        context, task.id, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    // API 30 (Android 11): setExactAndAllowWhileIdle funciona sem permissão especial
    // API 31+ (Android 12+): só usa exact se o usuário concedeu permissão; senão usa fallback
    when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent
                )
            }
        }
        else -> {
            // API 23–30: setExactAndAllowWhileIdle sempre disponível
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent
            )
        }
    }
}

fun cancelTaskNotification(context: Context, taskId: Int) {
    val alarmManager = context.getSystemService(AlarmManager::class.java)
    val intent = Intent(context, TaskAlarmReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(
        context, taskId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    alarmManager.cancel(pendingIntent)
}

fun cancelAllNotifications(context: Context, tasks: List<TaskEntity>) {
    tasks.forEach { cancelTaskNotification(context, it.id) }
}

fun scheduleAllNotifications(context: Context, tasks: List<TaskEntity>) {
    tasks.forEach { scheduleTaskNotification(context, it) }
}