package com.example.rotinapp

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.rotinapp.network.RetrofitInstance
import com.example.rotinapp.network.WeatherResponse
import kotlinx.coroutines.launch

// Coordenadas de Brasília - DF
private const val BRASILIA_LAT = -15.78
private const val BRASILIA_LON = -47.93

@Composable
fun ApiScreen(navController: NavController) {
    var weather by remember { mutableStateOf<WeatherResponse?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                weather = RetrofitInstance.api.getWeather(
                    latitude = BRASILIA_LAT,
                    longitude = BRASILIA_LON
                )
                loading = false
            } catch (e: Exception) {
                error = e.message ?: "Erro ao carregar clima"
                loading = false
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        IconButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier.padding(16.dp).align(Alignment.TopStart)
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
        }

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            when {
                loading -> CircularProgressIndicator()
                error.isNotEmpty() -> Text("Erro: $error")
                weather != null -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🌤 Clima Atual — Brasília", fontSize = 28.sp)
                    Spacer(modifier = Modifier.height(20.dp))
                    Text("Temperatura: ${weather!!.current_weather.temperature}°C")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Vento: ${weather!!.current_weather.windspeed} km/h")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Horário: ${weather!!.current_weather.time}")
                }
            }
        }
    }
}
