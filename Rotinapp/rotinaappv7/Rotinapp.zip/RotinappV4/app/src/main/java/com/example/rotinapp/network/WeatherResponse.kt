package com.example.rotinapp.network

data class WeatherResponse(
    val current_weather: CurrentWeather
)

data class CurrentWeather(
    val temperature: Double,
    val windspeed: Double,
    val time: String,
    val weathercode: Int // Adicionado para identificar a condição climática atual
)